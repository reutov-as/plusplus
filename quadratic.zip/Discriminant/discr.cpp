double Finddiscriminant(int a, int b, int c) {
	double D = b * b - 4 * a * c;
	return D;
}