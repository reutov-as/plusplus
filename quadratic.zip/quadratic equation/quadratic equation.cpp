#include <iostream>
#include <math.h>
#include "..//Solution/solution.cpp"
#pragma warning (disable: 4996)

using namespace std;


int main() {
	int a, b, c;
	cout << "Input a = ";
	cin >> a;
	cout << "Input b = ";
	cin >> b;
	cout << "Input c = ";
	cin >> c;
	Findsolution(a, b, c);
	return 0;
}